pkill -9 a.out
gcc serv.c

